# growgreen 식물키우기 TodoList 웹앱 개발

## 1. 프로젝트 정보

- [Notion](https://)
- [Figma](https://)
- 기간 :

## 2. 활용 모듈

- React 18
- React Router 6
- Emotion
- SCSS
- Fontawsome
- Tailwind
- axios
- AntDesign
- React Calendar
- Nivo Chart
- ESLint
- Prettier

## 3. 프로젝트 후기
