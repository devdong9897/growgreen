import React from "react";

const Diary = () => {
  return <></>;
};

export default Diary;
