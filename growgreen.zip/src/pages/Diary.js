import React, { useEffect, useState } from "react";
import { Navigate, Route, Routes } from "react-router-dom";

import { getDiaryDetail } from "../api/patchdiary";

import DiaryList from "./DiaryList";
import DiaryWrite from "./DiaryWrite";
import DiaryDetail from "./DiaryDetail";
import DiaryWriteEdit from "./DiaryWriteEdit";

const Diary = () => {
  // 다이어리 디테일 페이지 state 관리
  const [diaryDetailData, setDiaryDetailData] = useState(null);
  const getDiaryDetailData = async () => {
    try {
      const data = await getDiaryDetail();
      console.log(data);
      setDiaryDetailData(data);
    } catch (err) {
      console.log("다이어리 디테일 에러 : ", err);
    }
  };
  useEffect(() => {
    getDiaryDetailData();
  }, []);
  return (
    <Routes>
      <Route path="/" element={<Navigate to="list" replace />} />
      <Route path="/list" element={<DiaryList />} />
      <Route path="/write" element={<DiaryWrite />} />
      <Route
        path="/detail"
        element={<DiaryDetail />}
        diaryDetailData={diaryDetailData}
      />
      <Route path="/edit" element={<DiaryWriteEdit />} />
    </Routes>
  );
};

export default Diary;
